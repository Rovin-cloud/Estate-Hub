# Estate Hub — Hostinger Deployment Guide

## What's in this zip

```
estate-hub/
├── dist/
│   ├── index.mjs          ← Node.js server (fully self-contained bundle)
│   ├── pino-*.mjs         ← Logger workers (required alongside index.mjs)
│   └── public/            ← Built React frontend (served automatically)
│       ├── index.html
│       └── assets/
├── package.json
├── .env.example
└── DEPLOYMENT.md
```

---

## Step 1 — Set up PostgreSQL

Hostinger shared hosting uses MySQL. For this app you need **PostgreSQL**.
Free options: [Neon](https://neon.tech) · [Supabase](https://supabase.com) · [Railway](https://railway.app)

1. Create a free Postgres database on any of those providers.
2. Copy your connection string: `postgresql://user:password@host:5432/dbname`
3. Run this SQL once in your database console to create the schema:

```sql
CREATE TABLE IF NOT EXISTS leads (
  id SERIAL PRIMARY KEY, name TEXT NOT NULL, phone TEXT, email TEXT,
  source TEXT DEFAULT 'website', status TEXT DEFAULT 'new',
  notes TEXT, assigned_to TEXT,
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY, name TEXT NOT NULL, phone TEXT, email TEXT,
  nid TEXT, address TEXT, notes TEXT, clerk_user_id TEXT,
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS properties (
  id SERIAL PRIMARY KEY, project_name TEXT NOT NULL, unit_number TEXT,
  location TEXT, price NUMERIC(14,2), status TEXT DEFAULT 'available',
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY, title TEXT NOT NULL, description TEXT,
  lead_id INTEGER REFERENCES leads(id) ON DELETE SET NULL,
  assigned_to TEXT, due_date TIMESTAMP, status TEXT DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER REFERENCES customers(id) ON DELETE CASCADE,
  property_id INTEGER REFERENCES properties(id) ON DELETE SET NULL,
  installment_number INTEGER DEFAULT 1,
  total_amount NUMERIC(14,2) NOT NULL, paid_amount NUMERIC(14,2) DEFAULT 0,
  due_date TIMESTAMP, paid_date TIMESTAMP, status TEXT DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
);
```

---

## Step 2 — Set up Clerk (Auth)

1. Go to [clerk.com](https://clerk.com) → create a **Production** application.
2. In Clerk Dashboard → **Domains** → add your Hostinger domain (e.g. `yourdomain.com`).
3. Copy your **Publishable Key** (`pk_live_...`) and **Secret Key** (`sk_live_...`).

> **Important:** The frontend bundle in this zip was built with a placeholder Clerk key.
> Before uploading, rebuild with your real key — see Step 4.

---

## Step 3 — Upload to Hostinger

1. Log in to **hPanel** → **Node.js** → Create application.
2. Set:
   - **Node.js version**: 20 (or 22)
   - **Application root**: e.g. `/home/u123456/estate-hub`
   - **Startup file**: `dist/index.mjs`
3. Upload all files from this zip into that application root folder.
4. In **hPanel → Node.js → Environment variables**, add:

| Variable | Value |
|---|---|
| `DATABASE_URL` | `postgresql://...` (your Postgres connection string) |
| `CLERK_PUBLISHABLE_KEY` | `pk_live_...` |
| `CLERK_SECRET_KEY` | `sk_live_...` |
| `NODE_ENV` | `production` |

5. Click **Restart**.

---

## Step 4 — Rebuild frontend with your real Clerk key (Required!)

The Clerk publishable key is baked into the frontend at build time. You must rebuild it with your real production key:

```bash
# On your local machine (requires Node 20+ and pnpm)
git clone <your-repo>   # or unzip the source code
cd estate-hub

# Install dependencies
pnpm install

# Build frontend with your real Clerk key
VITE_CLERK_PUBLISHABLE_KEY=pk_live_YOUR_KEY \
  NODE_ENV=production BASE_PATH=/ PORT=3000 \
  pnpm --filter @workspace/crm run build

# Build server
pnpm --filter @workspace/api-server run build

# Copy frontend into server dist
cp -r artifacts/crm/dist/public artifacts/api-server/dist/public

# Re-zip and upload
zip -r estate-hub.zip artifacts/api-server/dist package.json .env.example
```

---

## Step 5 — First login & admin setup

1. Visit your domain — you'll see the Estate Hub sign-in page.
2. Sign up with your email.
3. Go to **Clerk Dashboard → Users** → click your user → **Public Metadata** → set:
   ```json
   { "role": "admin" }
   ```
4. Log out and back in — you now have full admin access.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| White/blank page | Clerk key mismatch — rebuild frontend with correct `pk_live_` key |
| `ENOTFOUND` / DB errors | Check `DATABASE_URL` is a valid `postgresql://` string |
| 401 on all API calls | `CLERK_SECRET_KEY` missing or wrong |
| App doesn't start | Confirm startup file is `dist/index.mjs`, not `index.js` |
